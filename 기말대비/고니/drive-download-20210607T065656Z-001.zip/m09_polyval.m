%% Polynomial representation
% $f(x) = 5 x^5 + 6 x^2 + 4 x + 2$
%
% Use polyval() to fine the value of $f(x)$ at $x=0$ and $x=1$.
%
% Plot the graph of $f(x)$ over $x=-1 \sim +2$.
%

